/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<stdlib.h>
int n,a[10];
int main()
{
    int choice,x,pos;
    printf("Enter the size of array");
    scanf("%d",&n);
    //creation of an array
    for(int i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    while(1)
    {
        printf("\n 1.Insertion of element at first position");
        printf("\n 2.Insertion of element at any position");
        printf("\n 3.Insertion of element at end position");
        printf("\n 4.Deletion of element at first position");
        printf("\n 5.Deletion of element at any position");
        printf("\n 6.Deletion of element at end position");
        printf("\n 7.Display the array");
        printf("\n Enter the choice :" );
        scanf("%d",&choice);
        switch(choice)
        {
           case 1:
           //Insertion of element at first position
           for(int i=n;i>0;i--)
           {
               a[i]=a[i-1];
           }
           printf("Enter the number:");
           scanf("%d",&x);
           a[0]=x;
           break;
           
           case 2:
           //Insertion of element at any position
           printf("Enter the number:");
           scanf("%d",&x);
           printf("Enter the position:");
           scanf("%d",&pos);
           for(int i=n;i>=pos;i--)
           {
               a[i]=a[i-1];
           }
           a[pos-1]=x;
           n++;
           break;
           
           case 3:
           //Insertion of element at end position
           printf("Ente the number:");
           scanf("%d",&x);
           a[n]=x;
           n++;
           break;
           
           case 4:
           //Deletion of element at first position
           for(int i=0;i<n;i++)
           {
               a[i]=a[i+1];
           }
           n--;
           break;
           
           case 5:
           //Deletion of element at any position
           printf("Enter the position:");
           scanf("%d",&pos);
           for(int i=pos-1;i<n;i++)
           {
               a[i]=a[i+1];
           }
           break;
           
           case 6:
           //Deletion of element at end position
           printf("\n Delete the element from end");
           n--;
           break;
           
           case 7:
           //Display the array
           printf("Displaying the elements:");
           for(int i=0;i<n;i++)
           {
               printf("%d\n",a[i]);
           }
           break;
           
           case 8:
           exit(0);
           default:printf("\n Invalid choice!");
           break;
           
        }
    }    

    return 0;
}
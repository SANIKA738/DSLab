/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<stdlib.h>

int main()
{
    int Top=-1,stack[10],x,n,i,choice;
    printf("Enter the size of stack:");
    scanf("%d",&n);
    while(1)
    {
        printf("\n 1.push:Insertion of Element in stack");
        printf("\n 2.pop:Deletion of Element in stack ");
        printf("\n 3.peek:Show topmost Element");
        printf("\n 4.underflow:Check whether the stack is empty");
        printf("\n 5.overflow:Check whether the stack is full");
        printf("\n 6.dislay:Show the element in the stack");
        printf("\n 7. exit");
        printf("\nEnter the choice:");
        scanf("%d",&choice);
        switch(choice)
        {
            case 1:
            //push:Insertion of stack
            if(Top==n-1)
            {
                printf("\n overflow!!");
            }
            else
            {
                printf("\n Enter the element of stack:");
                scanf("%d",&x);
                Top++;
                stack[Top]=x;
            }
            break;
            
            case 2:
            //pop:Deletion of stack
            if(Top==-1)
            {
                printf("\n underflow!!");
            }
            else
            {
                Top--;
            }
            break;
            
            case 3:
            //peek:Display topmost Element
            printf("show the topmost element :%d",stack[10]);
            break;
            
            case 4:
            //underflow
            if(Top==-1)
            {
                printf("\n Underflow!!");
            }
            else
            {
                printf("\n Not overflow!!");
            }
            break;
            
            case 5:
            //check the condition for overflow
            if(Top==n-1)
            {
                printf("\n overflow!!");
            }
            else
            {
                printf("\n Not overflow!!");
            }
            break;
            
            case 6:
            //Display the stack
            for(i=Top;i>=0;i--)
            {
                printf("\t\n%d",stack[i]);
            }
            break;
            
            case 7:
            exit(0);
           
            default:printf("\n Invalid choice!");
            break;
            
        }
    }
    
    
    

    return 0;
}
